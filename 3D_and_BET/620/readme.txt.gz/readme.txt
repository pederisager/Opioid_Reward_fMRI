Used 620_T1_3D_strukturell_SENSE_FSL.nii for 3D file
